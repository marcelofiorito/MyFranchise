sap.ui.define(["sap/ui/integration/Designtime"], function (Designtime) {
    "use strict";
    return function () {
        return new Designtime({
            form: {
                items: {
                    "destination": {
                        "manifestpath": "/sap.card/configuration/destinations/myfranchise-srv/name",
                        "type": "string",
                        "label": "Backend Destination",
                        "translatable": false
                    }
                }
            },
            preview: { modes: "Abstract" }
        });
    };
});