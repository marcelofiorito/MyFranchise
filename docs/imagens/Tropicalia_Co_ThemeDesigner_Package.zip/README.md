# Tropicália Co. — SAP UI Theme Designer Package
## Versão 1.0 | Agosto 2026

Este pacote contém os artefatos de tematização para o SAP Work Zone Advanced.

---

## ARQUIVOS

| Arquivo | Uso |
|---|---|
| parameters.json | Parâmetros completos para Expert Mode do Theme Designer |
| quick_theming_reference.json | Valores essenciais para o Quick Theming |
| custom_css_workzone.css | CSS pronto para colar em Work Zone > Site Settings > Custom CSS |
| metadata.json | Metadados da marca e paleta completa |

---

## COMO USAR

### Opção A — Theme Designer (recomendado)
1. Acesse SAP Work Zone Advanced > Administração > UI Theme Designer
2. Crie um novo tema baseado em `sap_horizon`
3. Em Quick Theming, use os valores de `quick_theming_reference.json`
4. Em Expert Mode, copie os valores de `parameters.json` para os campos correspondentes
5. Salve e publique o tema

### Opção B — Custom CSS
1. Acesse Site Manager > Settings > Appearance > Custom CSS
2. Cole o conteúdo de `custom_css_workzone.css`
3. Salve

### Opção C — Importar o ZIP (se suportado pela sua versão)
1. No Theme Designer, use a função "Import Theme" ou "Import Parameters"
2. Selecione este arquivo ZIP

---

## PALETA RESUMIDA

| Cor          | Hex       | Uso principal           |
|---|---|---|
| Verde Floresta | #0B3D2E | Shell bar, headers      |
| Coral Tropical | #FF5A3C | Botões CTA, links       |
| Amarelo Solar  | #FFCC2E | Badges, destaques       |
| Areia Tropical | #FDF6EC | Fundo de páginas        |
| Noite Tropical | #12241D | Texto principal         |
| Turquesa       | #22B8B0 | Mensagens informativas  |
| Verde Médio    | #1F7A4D | Status de sucesso       |

---
Tagline: "Summer has a homeland" · Base Theme: sap_horizon
